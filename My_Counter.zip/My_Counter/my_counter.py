import tkinter as tk
from tkinter import ttk
import random
import os
import json
import pygame
import time
import sys

# Helper for PyInstaller resource paths (if you bundle as an .exe)
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# Path for local config to remember username
CONFIG_FILE = "config.json"

def load_config():
    global username
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            data = json.load(f)
            username_value = data.get("username", "").strip()
            if username_value:
                username = username_value
                return True
    return False

def save_config():
    with open(CONFIG_FILE, "w") as f:
        json.dump({"username": username}, f)

# Initialize pygame mixer
pygame.mixer.init()

# Load sounds
win_sound = pygame.mixer.Sound(resource_path("win.mp3"))
lose_sound = pygame.mixer.Sound(resource_path("lose.wav"))

# Constants
number_range = (1, 100)
timer_limit = 600  # seconds
MAX_TRIES = 10
leaderboard_file = "global_leaderboard.json"
friends_file = "friends.json"

# Global state
username = ""
player_names = []
current_player = 0
global_leaderboard = {}
friends_list = []
number_to_guess = 0
guessed_correctly = False
tries_left = MAX_TRIES
start_time = 0

# Messages
success_messages = ["Awesome", "Good Job", "Well Done"]
fail_messages = ["Next time better", "Bad Luck"]

# -------- Core Game Logic --------
def validate_input(new_value):
    return new_value.isdigit() and len(new_value) <= 3 if new_value else True

def animate_lose_message(text, index=0, display=""):
    if index < len(text):
        display += text[index]
        result_label.config(text=display, fg="red")
        result_label.after(100, lambda: animate_lose_message(text, index+1, display))

def check_guess():
    global guessed_correctly, tries_left, start_time
    if time.time() - start_time > timer_limit:
        message_label.config(text="Time's up! You lose.", fg="red")
        animate_lose_message("YOU LOSE!")
        pygame.mixer.Sound.play(lose_sound)
        disable_game()
        return

    guess = guess_entry.get()
    if not guess.isdigit() or not (number_range[0] <= int(guess) <= number_range[1]):
        result_label.config(text=f"Enter a number between {number_range[0]} and {number_range[1]}", fg="red")
        return

    guess = int(guess)
    tries_left -= 1

    if guess == number_to_guess:
        guessed_correctly = True
        elapsed = int(time.time() - start_time)
        global_leaderboard[username] = global_leaderboard.get(username, 0) + 1
        save_leaderboard()
        message_label.config(text=f"{random.choice(success_messages)} in {elapsed} seconds!", fg="green")
        animate_lose_message("YOU WIN!")
        pygame.mixer.Sound.play(win_sound)
        disable_game()
    elif tries_left <= 0:
        message_label.config(text=random.choice(fail_messages), fg="red")
        animate_lose_message("YOU LOSE!")
        pygame.mixer.Sound.play(lose_sound)
        disable_game()
    else:
        hint = "Too low!" if guess < number_to_guess else "Too high!"
        result_label.config(text=f"{hint} {tries_left} tries left", fg="blue")
        message_label.config(text=f"{player_names[current_player]}'s Turn", fg="green")

    guess_entry.delete(0, tk.END)
    update_leaderboard()

def disable_game():
    guess_entry.config(state="disabled")
    submit_button.config(state="disabled")

def reset_game():
    global number_to_guess, guessed_correctly, tries_left, start_time
    number_to_guess = random.randint(*number_range)
    guessed_correctly = False
    tries_left = MAX_TRIES
    start_time = time.time()
    guess_entry.config(state="normal")
    submit_button.config(state="normal")
    guess_entry.delete(0, tk.END)
    result_label.config(text="", fg="green")
    message_label.config(text=f"{player_names[current_player]}'s Turn", fg="green")
    update_leaderboard()

def update_leaderboard():
    leaderboard_text.config(state="normal")
    leaderboard_text.delete("1.0", tk.END)
    for name, score in sorted(global_leaderboard.items(), key=lambda x: x[1], reverse=True):
        leaderboard_text.insert(tk.END, f"{name}: {score} wins\n")
    leaderboard_text.config(state="disabled")

def save_leaderboard():
    with open(leaderboard_file, "w") as f:
        json.dump(global_leaderboard, f)

def load_leaderboard():
    global global_leaderboard
    if os.path.exists(leaderboard_file):
        with open(leaderboard_file, "r") as f:
            global_leaderboard = json.load(f)

def load_friends():
    global friends_list
    if os.path.exists(friends_file):
        with open(friends_file, "r") as f:
            data = json.load(f)
            friends_list = data.get(username, [])

def save_friends():
    data = {}
    if os.path.exists(friends_file):
        with open(friends_file, "r") as f:
            data = json.load(f)
    data[username] = friends_list
    with open(friends_file, "w") as f:
        json.dump(data, f)

def add_friend_from_search(friend_name):
    if friend_name not in friends_list:
        friends_list.append(friend_name)
        save_friends()
        display_friends()
        invite_status_label.config(text=f"{friend_name} added as a friend!", fg="green")
    else:
        invite_status_label.config(text=f"{friend_name} is already your friend.", fg="orange")

def search_players():
    query = search_entry.get().strip().lower()
    for w in search_results_frame.winfo_children():
        w.destroy()
    if not query:
        return
    matches = [u for u in global_leaderboard if query in u.lower() and u != username]
    for u in matches:
        frame = tk.Frame(search_results_frame, bg="#1e1e2f")
        frame.pack(fill="x", pady=2, padx=10)
        tk.Label(frame, text=u, font=("Segoe UI",12), bg="#1e1e2f", fg="white").pack(side="left")
        btn = ttk.Button(frame, text="Add", command=lambda x=u: add_friend_from_search(x))
        btn.pack(side="right")
        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)

def display_friends():
    friends_text.config(state="normal")
    friends_text.delete("1.0", tk.END)
    for f in friends_list:
        friends_text.insert(tk.END, f"{f}: {global_leaderboard.get(f,0)} wins\n")
    friends_text.config(state="disabled")

def set_difficulty(level):
    global number_range, timer_limit, MAX_TRIES
    if level == "Easy":
        number_range = (1,50); MAX_TRIES = 5
    elif level == "Medium":
        number_range = (1,100); MAX_TRIES = 10
    else:
        number_range = (1,500); MAX_TRIES = 40
    timer_limit = 600
    difficulty_status_label.config(
        text=f"{level}: Range {number_range[0]}–{number_range[1]}, {MAX_TRIES} tries, {timer_limit//60} min"
    )

def start_game():
    global username, player_names
    username_input = username_entry.get().strip()
    if username_input:
        username = username_input
        save_config()
    player_names = [username, "Opponent"]
    welcome_frame.pack_forget()
    main_frame.pack(fill="both", expand=True)
    load_leaderboard(); load_friends(); reset_game(); update_leaderboard(); display_friends()

# -------- GUI Setup --------
window = tk.Tk()
window.title("Number Guesser")
window.geometry("900x700")
window.config(bg="#1e1e2f")

style = ttk.Style()
style.theme_use("clam")
style.configure("TNotebook", background="#1e1e2f", borderwidth=0)
style.configure("TNotebook.Tab", background="#33334d", foreground="white", padding=[10,6])
style.map("TNotebook.Tab", background=[("selected","#4CAF50")])
style.configure("TFrame", background="#1e1e2f")
style.configure("TLabel", background="#1e1e2f", foreground="white", font=("Segoe UI",12))
style.configure("TButton", background="#4CAF50", foreground="white", font=("Segoe UI",11), padding=6)
style.configure("TEntry", fieldbackground="#2c2c3c", foreground="white", insertcolor="white")

# Hover callbacks
def on_enter(e): e.widget.config(background="#5fb760")
def on_leave(e): e.widget.config(background="#4CAF50")

vcmd = window.register(validate_input)

# Welcome Screen
welcome_frame = tk.Frame(window, bg="#1e1e2f")
# Only show welcome if no saved username
if not load_config():
    welcome_frame.pack(fill="both", expand=True)
    tk.Label(welcome_frame, text="Welcome to Number Guesser!", font=("Segoe UI",24,"bold"),
             bg="#1e1e2f", fg="white").pack(pady=40)
    tk.Label(welcome_frame, text="Enter your username:", font=("Segoe UI",14),
             bg="#1e1e2f", fg="white").pack(pady=10)
    username_entry = ttk.Entry(welcome_frame, font=("Segoe UI",14), width=30)  # no validation here
    username_entry.pack(pady=10)
    start_btn = ttk.Button(welcome_frame, text="Start Game", command=start_game)
    start_btn.pack(pady=20)
    start_btn.bind("<Enter>", on_enter); start_btn.bind("<Leave>", on_leave)
else:
    # If config loaded, auto-start
    start_game()

# Main Tabs
main_frame = tk.Frame(window, bg="#1e1e2f")
notebook = ttk.Notebook(main_frame)
game_frame = ttk.Frame(notebook)
leaderboard_frame = ttk.Frame(notebook)
invite_frame = ttk.Frame(notebook)
difficulty_frame = ttk.Frame(notebook)
notebook.add(game_frame, text="🎮 Game")
notebook.add(leaderboard_frame, text="🏆 Leaderboard")
notebook.add(invite_frame, text="👥 Friends")
notebook.add(difficulty_frame, text="⚙️ Difficulty")
notebook.pack(expand=True, fill="both", padx=20, pady=20)

# Game Tab UI
tk.Label(game_frame, text="Number Guesser", font=("Segoe UI",20,"bold"),
         bg="#1e1e2f", fg="white").pack(pady=10)
message_label = tk.Label(game_frame, text="", font=("Segoe UI",14),
                         bg="#1e1e2f", fg="green")
message_label.pack(pady=5)
tk.Label(game_frame, text="Enter a number:", font=("Segoe UI",12),
         bg="#1e1e2f", fg="white").pack()
guess_entry = ttk.Entry(game_frame, font=("Segoe UI",14),
                        validate="key", validatecommand=(vcmd, "%P"))
guess_entry.pack(pady=5)
submit_button = ttk.Button(game_frame, text="Submit Guess", command=check_guess)
submit_button.pack(pady=5)
submit_button.bind("<Enter>", on_enter); submit_button.bind("<Leave>", on_leave)
retry_button = ttk.Button(game_frame, text="Retry", command=reset_game)
retry_button.pack(pady=5)
retry_button.bind("<Enter>", on_enter); retry_button.bind("<Leave>", on_leave)
result_label = tk.Label(game_frame, text="", font=("Segoe UI",16),
                        bg="#1e1e2f", fg="white")
result_label.pack(pady=10)

# Leaderboard Tab UI
tk.Label(leaderboard_frame, text="Global Leaderboard", font=("Segoe UI",16,"bold"),
         bg="#1e1e2f", fg="white").pack(pady=10)
leaderboard_text = tk.Text(leaderboard_frame, font=("Segoe UI",12),
                           bg="#2c2c3c", fg="white", height=10, width=30)
leaderboard_text.pack(pady=5)
leaderboard_text.config(state="disabled")

# Friends Tab UI
tk.Label(invite_frame, text="Add Friends", font=("Segoe UI",16,"bold"),
         bg="#1e1e2f", fg="white").pack(pady=10)
search_entry = ttk.Entry(invite_frame, font=("Segoe UI",12))
search_entry.pack(pady=5, side=tk.LEFT, padx=(10,0))
search_btn = ttk.Button(invite_frame, text="Search", command=search_players)
search_btn.pack(pady=5, side=tk.LEFT, padx=5)
search_btn.bind("<Enter>", on_enter); search_btn.bind("<Leave>", on_leave)
search_results_frame = tk.Frame(invite_frame, bg="#1e1e2f")
search_results_frame.pack(fill="x", pady=5)
tk.Label(invite_frame, text="Your Friends' Scores", font=("Segoe UI",14,"bold"),
         bg="#1e1e2f", fg="white").pack(pady=10)
friends_text = tk.Text(invite_frame, font=("Segoe UI",12),
                       bg="#2c2c3c", fg="white", height=8, width=30)
friends_text.pack(pady=5)
friends_text.config(state="disabled")
invite_status_label = tk.Label(invite_frame, text="", font=("Segoe UI",12),
                               bg="#1e1e2f", fg="white")
invite_status_label.pack(pady=5)

# Difficulty Tab UI
tk.Label(difficulty_frame, text="Select Difficulty", font=("Segoe UI",16,"bold"),
         bg="#1e1e2f", fg="white").pack(pady=10)
for lvl, txt in [("Easy","Easy (1-50)"),("Medium","Medium (1-100)"),("Hard","Hard (1-500)")]:
    btn = ttk.Button(difficulty_frame, text=txt, command=lambda l=lvl: set_difficulty(l))
    btn.pack(pady=5)
    btn.bind("<Enter>", on_enter); btn.bind("<Leave>", on_leave)
difficulty_status_label = tk.Label(difficulty_frame, text="", font=("Segoe UI",12),
                                   bg="#1e1e2f", fg="white")
difficulty_status_label.pack(pady=10)

# Launch
main_frame.pack(fill="both", expand=True)
window.mainloop()